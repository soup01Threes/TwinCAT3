
import numpy as np
import time
from PIL import Image
from pycoral.adapters import classify
from pycoral.adapters import common
from pycoral.utils.dataset import read_label_file
from pycoral.utils.edgetpu import make_interpreter


from opcua import Client
from opcua import ua
import os.path
import datetime

#OPCUA Setup
ENDPOINT="opc.tcp://192.168.3.124:4840"
client=Client(ENDPOINT)
NodeID2Server='ns=4;s=GVL_OPCUAServer.ReadFromPI4'
NodeIDFromServer='ns=4;s=GVL_OPCUAServer.WriteToPI4'
BASEPATH='/home/pi/ftp'

#TPU Setup
LABELPATH='imagenet_labels.txt'
MODELPATH='mobilenet_v1_0.25_128_quant_edgetpu.tflite'
top_k=2
threshold=0.0
count=2
input_mean=128
input_std=128

DEBUG=False

def getCurrentTime():
    return str(datetime.datetime.now())

def writetext2File(message):
    with open('/home/pi/ftp/files/log.txt', 'a') as log:
        msg=getCurrentTime()+':'+message+'\n'
        print(msg)
        log.write(msg)

def main():
    try:
        client=Client(ENDPOINT)
        writetext2File('Connecting to OPCUA Server in EndPoint:'+ENDPOINT)
        client.connect()
        writetext2File('Connecting to OPCUA Server in EndPoint:'+ENDPOINT+'..OK!')
        Node2Server=client.get_node(NodeID2Server)
        NodeFromServer=client.get_node(NodeIDFromServer)
        client.load_type_definitions()
        
        Node2ServerValue=Node2Server.get_value()
        NodeFromServerValue=NodeFromServer.get_value()
        Node2ServerValue.bTPUReady=False
        ReadyCount=0
        CommandReceived=False
        
        Step=0
        
        #TPU Init
        #Load the Label
        labels = read_label_file(LABELPATH) if LABELPATH else {}
        writetext2File('Label is Loaded.'+LABELPATH)
        
        #Load the Model
        interpreter = make_interpreter(*MODELPATH.split('@'))
        interpreter.allocate_tensors()
        writetext2File('Model is Loaded.'+MODELPATH)
        
        # Model must be uint8 quantized
        if common.input_details(interpreter, 'dtype') != np.uint8:
                raise ValueError('Only support uint8 input type.')
        
        ImageFiles=None
        
        while True:
            
                NodeFromServerValue=NodeFromServer.get_value()
                
                ReadyCount=ReadyCount+1
                Node2ServerValue.bTPUReady=True
                Node2ServerValue.bClientReady=True
                if ReadyCount<=200:
                    Node2ServerValue.bClientReady=False
                else:
                    Node2ServerValue.bClientReady=True
                    ReadyCount=ReadyCount+1
                    if ReadyCount >=400:
                        ReadyCount=0
                        
                
                if NodeFromServerValue.bStart2Classification and not CommandReceived:
                    #Command from OPCUA Server
                    writetext2File('Command is recevied..')
                    print('Command is received..')
                    CommandReceived=True
                    
                    writetext2File('Path is :'+BASEPATH+NodeFromServerValue.sImageName)
                    print("path with:"+BASEPATH+NodeFromServerValue.sImageName)
                    
                    #Node2Server.set_value(ua.DataValue(Node2ServerValue))
                    
                    ImageFiles=os.path.isfile(BASEPATH+NodeFromServerValue.sImageName)
                    print('----')
                    
 
                    
                if CommandReceived and ImageFiles :
                    Node2ServerValue.bBusy=True
                    #Node2Server.set_value(ua.DataValue(Node2ServerValue))
                    print('Image is found..')
                    writetext2File('Path is found.')
                    if Step == 2:
                            i=0
                            # Run inference
                            writetext2File('Inferenice with time.,The first inference on Edge TPU is slow because it includes loading the model into Edge TPU memory.')
                            for _ in range(count):
                                    start = time.perf_counter()
                                    interpreter.invoke()
                                    inference_time = time.perf_counter() - start
                                    classes = classify.get_classes(interpreter, top_k, threshold)
                                    writetext2File('%.1fms' % (inference_time * 1000))
                            for c in classes:
                       
                                    writetext2File('%s: %.5f' % (labels.get(c.id, c.id), c.score))
                                    Node2ServerValue.arrResult[i].Label=labels.get(c.id, c.id)
                                    Node2ServerValue.arrResult[i].Score=c.score
                                    i=i+1
                            Step=99
                    if Step == 1:
                            params = common.input_details(interpreter, 'quantization_parameters')
                            scale = params['scales']
                            zero_point = params['zero_points']
                            mean = input_mean
                            std = input_std
                            writetext2File('Step is 1,Initing the Parameters.')
                            if abs(scale * std - 1) < 1e-5 and abs(mean - zero_point) < 1e-5:
                                    # Input data does not require preprocessing.
                                    common.set_input(interpreter, image)
                            else:
                                    # Input data requires preprocessing
                                    normalized_input = (np.asarray(image) - mean) / (std * scale) + zero_point
                                    np.clip(normalized_input, 0, 255, out=normalized_input)
                                    common.set_input(interpreter, normalized_input.astype(np.uint8))
                            Step=2
                    
                    if Step == 0:
                            size = common.input_size(interpreter)
                            s=BASEPATH+NodeFromServerValue.sImageName
                            image = Image.open(s).convert('RGB').resize(size, Image.ANTIALIAS)
                            Step=1
                            writetext2File('Step is 0,Got the image from TwinCAT and Open it.')
                            for r in Node2ServerValue.arrResult:
                                    r.Label=''
                                    r.Score=0.0

                #not NodeFromServerValue.bStart2Classification and
                if Step > 0 and Step <99:
                    Node2ServerValue.bBusy=True
                    print('--t')
                else:
                    CommandReceived=False
                    Node2ServerValue.bBusy=False
                    Step=0
                    ImageFiles=None       

                    
                Node2Server.set_value(ua.DataValue(Node2ServerValue))
                    


    finally:
        client.disconnect()
        writetext2File('Disconnected from OPCUA Sever.')

if __name__ == '__main__':
  writetext2File('Script is started.')
  main()
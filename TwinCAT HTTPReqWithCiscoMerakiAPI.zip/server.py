import http.server
import socketserver
import json
import paho.mqtt.client as mqtt
import time

def on_connect(client,userdata,flag,rc):
        print('connected with result code'+str(rc))

def on_disconnect(client,userdata,rc):
        if rc!=0:
                print('something wrong..')

def on_publish(client,userdata,mid):
        print('publish:{0}'.format(mid))

URL='127.0.0.1'
PORT=1883
BASE='/Switch1'
FIX_TOPIC_WEBHOOK='Wehook'
FIX_TOPIC_ALERT='Alert'
FIX_TOPIC_DATE='Date'

class MyHandler(http.server.BaseHTTPRequestHandler):
        def do_POST(self):
                self.send_response(200)
                self.end_headers()
                print(self.path)
                content_length = int(self.headers['Content-Length'])
                #post_data = self.rfile.read(content_length)
                #post_data_string=post_data.decode()
                #post_data_json=json.loads(post_data_string)
                data_in_json=json.loads(self.rfile.read(content_length).decode())

                #d['sentAt']
            #d['deviceName']
            #d['deviceSerial']
            #d['alertType']
            #d['alertTypeId']
            #d['alertLevel']
            #d['occurredAt']

                client=mqtt.Client()
                client.on_connect=on_connect
                client.on_disconnect=on_disconnect
                client.on_publish=on_publish
                client.connect(URL,PORT,60)
                #client.publish('/Switch1/hello','hallo')
                NetworkName=data_in_json['networkName']
                DeviceName=data_in_json['deviceName']

                client.publish('/'+NetworkName+'/'+DeviceName+'/'+FIX_TOPIC_WEBHOOK+'/'+FIX_TOPIC_ALERT+'/ID/',data_in_json['alertTypeId'])
                client.publish('/'+NetworkName+'/'+DeviceName+'/'+FIX_TOPIC_WEBHOOK+'/'+FIX_TOPIC_ALERT+'/Type/',data_in_json['alertType'])
                client.publish('/'+NetworkName+'/'+DeviceName+'/'+FIX_TOPIC_WEBHOOK+'/'+FIX_TOPIC_ALERT+'/Level/',data_in_json['alertLevel'])
                client.publish('/'+NetworkName+'/'+DeviceName+'/'+FIX_TOPIC_WEBHOOK+'/'+FIX_TOPIC_ALERT+'/Occurred/',data_in_json['occurredAt'])
                client.disconnect()



        def do_GET(self):
                self.send_response(200,"GET is received.")
                print("GET is received")
                self.end_headers()

with socketserver.TCPServer(("", 8001), MyHandler) as httpd:
        httpd.serve_forever()


import paho.mqtt.client as mqtt
import time

def on_connect(client,userdata,flag,rc):
    print('Connected with result code '+str(rc))
    client.subscribe('RoboDK/Station/s1/Lamp/Red')

def on_disconnect(client,userdata,rc):
    if rc !=0:
        print('Something Wrong..')

def on_publish(client,userdata,mid):
    print('publish: {0}'.format(mid))
    
BROCKER_URL='192.168.1.50'
BROCKET_PORT=1883
    
client=mqtt.Client()
client.on_connect=on_connect
client.on_disconnect=on_disconnect
client.on_publish=on_publish

client.connect(BROCKER_URL,BROCKET_PORT,60)
count=0

while count<1000:
    ret=client.publish('RoboDK/Station/s1/Lamp/Yellow',str(count))
    ret=client.publish('RoboDK/Station/s1/Lamp/Red',str(count+200))
    ret=client.publish('RoboDK/Station/s1/Lamp/Green',str(count+100))
    count=count+1
    time.sleep(1)
client.disconnect()
    
    